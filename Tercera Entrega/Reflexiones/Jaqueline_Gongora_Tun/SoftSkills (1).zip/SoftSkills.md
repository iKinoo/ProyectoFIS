﻿Habilidades blandas para la gestión del proceso de software relacionadas con estimación, planificación, seguimiento o control

Comunicación: Poseyendo una buena forma de expresar las ideas que se tienen con los compañeros de trabajo, es vital para poder discutir acerca de los puntos clave que se requieren, los puntos débiles y aspectos a mejorar del plan para encontrar la mejor solución. Un ejemplo de esto se presenta al elaborar los requerimientos de un proyecto de software, donde se precisa de una comunicación adecuada con los clientes para describir la solución a los problemas que se plantean. 

Otra habilidad que se considera importante es la colaboración, puesto que con esta se pueden realizar sprints, los cuales, son reuniones del equipo de trabajo en las que se muestran los avances que se tuvieron respecto al proyecto. Sin la colaboración de todo el equipo no es posible generar procesos.

De igual manera, la organización permite que los equipos de trabajo realicen las actividades que le corresponde a cada miembro, generando una armonía y sincronización para producir lo requerido en cortos periodos de tiempo; así como agilizando los trabajos individuales.

